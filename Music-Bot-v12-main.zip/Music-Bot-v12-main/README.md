# Setup
- Clique em **Star** neste projeto
- Adicionar TOKEN no arquivo `.env`
- Preencha todas as coisas em `config.json`
- Adicione a chave de API do YouTube em `config.js`

**Seu Bot está pronto!**

[<img src="https://canary.discordapp.com/api/guilds/664835490985410588/widget.png?style=banner2">](https://discord.gg/TEMauza)

# GitHub Repositories 

[Click Here](https://github.com/Saddam171?tab=repositories) 

# Social 
<a href="https://instagram.com/rz.ung" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/instagram.svg" alt="rz.ung" height="30" width="40" /></a>
[Instagram](https://www.instagram.com/rz.ung/)

<a href="https://discord.gg/! ᴏғᴘ ⚡ Resilient |ᴿᴶ 🇦🇷#0019" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/discord.svg" alt="! ᴏғᴘ ⚡ Resilient |ᴿᴶ 🇦🇷#0019" height="30" width="40" /></a>
[Discord](https://discord.gg/TEMauza)
